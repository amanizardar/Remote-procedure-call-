import json
'''opening/generating rpc_server file'''
out = open('rpc_server.py','w')

'''loading json object in am_c'''
json_file = open('contract.json','r')
am_c = json.load(json_file)
json_file.close()

ans = "from server_procedures import *\n"
ans += "import json\n"
ans += "import socket\n"
ans += "soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)\n"
ans += "soc.bind(('',22222))\n"
ans += "soc.listen(5)\n"
ans += "while 1:\n"
ans += "\tcon,z = soc.accept()\n"
ans += "\tstr_p  = con.recv(1024).decode()\n"
ans += "\texec('rep =' + str_p)\n"
ans += "\trep = str(rep)\n"
ans += "\tcon.send(rep.encode())\n"  

out.write(ans)




out.close()