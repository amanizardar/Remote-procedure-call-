import json

out = open('rpc_client.py','w')

ans = "import socket\n"
ans += "import json\n"
ans += "port = 22222\n"
ans += 'json_file = open("contract.json")\n'
ans += "data = json.load(json_file)\n"
ans += "json_file.close()\n"

json_file = open("contract.json")
data = json.load(json_file)
json_file.close()

for procedure in data['remote_procedures']:

    ans+="def "
    
    fun_call = procedure['procedure_name'] +"("
    for i in range(len(procedure['parameters'])):
        fun_call+="arg" + str(i) +","
    fun_call+=")"

    ans+=fun_call + ":\n"

    to_pass = procedure['procedure_name'] +"("
    ans+="\treq = '" + to_pass +"'"

    for i in range(len(procedure['parameters'])):
        if procedure['parameters'][i]["data_type"] == "str":
            ans+="+'\"'+str(arg" + str(i) + ")+'\"'" +"+','"  
            continue  
        ans+="+str(arg" + str(i) + ")" +"+','"
    ans += "+')'\n"
    
    ans += "\tsoc = socket.socket()\n"
    ans += "\tsoc.connect(('127.0.0.1', port))\n"
    ans += "\tsoc.send(req.encode())\n"
    ans += "\trep = soc.recv(1024).decode()\n"
    ans += "\trep = "+ procedure['return_type'] + "(rep)\n"
    ans += "\treturn rep\n"


out.write(ans)
out.close()
